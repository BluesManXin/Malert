package com.github.ra2.item;

import net.minecraft.item.Item;

public class ItemSjmcv extends Item {
    public ItemSjmcv() {
        super();
    }
}