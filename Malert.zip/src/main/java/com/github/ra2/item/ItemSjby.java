package com.github.ra2.item;

import net.minecraft.item.Item;

public class ItemSjby extends Item {
    public ItemSjby() {
        super();
    }
}

