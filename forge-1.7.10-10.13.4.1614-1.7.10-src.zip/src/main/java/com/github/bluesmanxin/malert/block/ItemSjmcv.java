package com.github.bluesmanxin.malert.block;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemSjmcv extends Item {
    public ItemSjmcv() {
        this.setUnlocalizedName("sj_mcv");
        this.setCreativeTab(CreativeTabs.tabMaterials); // 设置所属的创造模式标签
    }

    @Override
    public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ) {
        // 获取目标位置的方块
        Block blockAtTarget = world.getBlock(x, y, z);

        // 获取放置位置
        if (blockAtTarget.isReplaceable(world, x, y, z)) {
            // 如果目标方块可以被替换（如草丛），直接放置
        } else {
            // 如果目标方块不能被替换，放置到相邻位置
            if (side == 0) y--;
            if (side == 1) y++;
            if (side == 2) z--;
            if (side == 3) z++;
            if (side == 4) x--;
            if (side == 5) x++;
        }

        // 检查玩家是否有权限编辑这个位置
        if (!player.canPlayerEdit(x, y, z, side, stack)) {
            return false;
        }

        // 检查这个位置是否可以放置方块
        if (!world.isAirBlock(x, y, z)) {
            return false;
        }

        // 放置方块 sjmcvBlock
        if (!world.isRemote) {
            world.setBlock(x, y, z, BlockLoader.sjmcvBlock); // 假设 ModBlocks 是你的方块注册类
        }

        // 减少物品数量
        if (!player.capabilities.isCreativeMode) {
            stack.stackSize--;
        }

        return true; // 返回 true 表示交互成功
    }
}
