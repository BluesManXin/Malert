package com.github.bluesmanxin.malert.item;

import net.minecraft.item.Item;

public class ItemSjby extends Item {
    public ItemSjby() {
        super();
    }
}

