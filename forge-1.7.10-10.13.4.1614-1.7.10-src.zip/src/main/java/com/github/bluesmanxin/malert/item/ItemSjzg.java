package com.github.bluesmanxin.malert.item;

import net.minecraft.item.Item;

public class ItemSjzg extends Item {
    public ItemSjzg() {
        super();

    }
}
